CS5435 HW4

Included are two directories:

demo/
This contains the demo target meet.c. 

sploits/
This contains the starter code for your exploits. 

targets/
This contains the targets. You can build the targets by running "sudo make" in targets/. 
The resulting executables will be placed in /tmp/ with appropriate
permissions.


